﻿using ConsoleApp2;


namespace spoof
{
    static class Program
    {

        public static void Main()
        {
            Console.Clear();
            Console.Title = "Spoofer Tutorial";
            Console.Write("\n[1] Spoof\n\n[2] Check Serials\n\n[3] Clean Traces\n\n\nEnter Your Choice:");


            int choice;
                if (int.TryParse(Console.ReadLine(), out choice))
            {
                switch (choice)
                {
                    case 1:
                        Console.Clear ();
                        Spoof.Temp();
                        Thread.Sleep (3000);
                        Spoof.Mac();
                        Thread.Sleep(8000);
                        Console.WriteLine("Done Spoofing!");
                        break;

                    case 2:
                        Console.Clear ();
                        Spoof.Serials();
                        break;

                    case 3:
                        Console.Clear();
                        Spoof.Clean();
                        Thread.Sleep(1000);
                        Console.WriteLine("Done Cleaning Traces");
                        break;

                    default:
                        Console.WriteLine("Invalid Choice. Please enter a valid option");
                        break;


                }

            }









        }




    }




}